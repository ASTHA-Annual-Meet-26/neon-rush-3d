NEON RUSH 3D — Android Studio Project

এই ZIP-এ আপনার V62 গেমটি Android WebView অ্যাপ হিসেবে প্যাকেজ করা হয়েছে।

APK বানানোর নিয়ম:
1. Android Studio ইনস্টল করুন।
2. ZIP extract করুন।
3. Android Studio > Open দিয়ে NeonRush3D ফোল্ডারটি খুলুন।
4. Gradle Sync সম্পন্ন হতে দিন (প্রথমবার internet লাগবে)।
5. Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।
6. APK পাবেন: app/build/outputs/apk/debug/app-debug.apk

প্রয়োজন:
- Android Studio
- JDK 17
- Android SDK Platform 35
- Gradle 8.9 (Android Studio Gradle Sync এটি ডাউনলোড করতে পারে)

গুরুত্বপূর্ণ:
- গেমটি landscape ও full-screen মোডে চলবে।
- Three.js লাইব্রেরি CDN থেকে লোড হয়, তাই বর্তমান সংস্করণে প্রথমবার এবং খেলার সময় internet connection প্রয়োজন।
- Package ID: com.neonrush3d.game
- App name: NEON RUSH 3D
